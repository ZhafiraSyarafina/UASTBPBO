//interface
public interface DataPemesanan {
    public void noFaktur();
    public void namaPelanggan();
    public void noHP();
    public void alamat();
    public void jenisPesanan();
    public void hargaBantal();
    public void jumlahPesanan();
    public void totalHarga();


}
